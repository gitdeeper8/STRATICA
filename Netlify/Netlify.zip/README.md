# 🪨 STRATICA Netlify Deployment

## Project Overview
**STRATICA** (Stratigraphic Pattern Recognition & Paleoclimatic Temporal Reconstruction) is a Physics-Informed AI framework for decoding Earth's stratigraphic record. This repository contains the Netlify deployment configuration for the live dashboard and API.

## Live Site
- **Main Dashboard:** [https://stratica.netlify.app](https://stratica.netlify.app)
- **Reports:** [https://stratica.netlify.app/reports](https://stratica.netlify.app/reports)
- **Alerts:** [https://stratica.netlify.app/alerts](https://stratica.netlify.app/alerts)
- **Basins:** [https://stratica.netlify.app/basins](https://stratica.netlify.app/basins)
- **API Endpoint:** [https://stratica.netlify.app/api](https://stratica.netlify.app/api)
- **Documentation:** [https://stratica.readthedocs.io](https://stratica.readthedocs.io)

## Project Statistics
- **TCI Accuracy:** 96.2%
- **Sedimentary Basins:** 47 basins
- **Continents:** 6 continents
- **Datasets:** 2,800+ stratigraphic records
- **Study Period:** 4.5 billion years
- **Orbital Precision:** ±1,200 years
- **Isotope RMSD:** 0.0018‰

## Directory Structure
```

Netlify/
├── public/           # Static HTML/CSS/JS files
│   ├── index.html    # Main dashboard
│   ├── reports.html  # Reports dashboard
│   ├── alerts.html   # Active alerts
│   ├── basins.html   # Basin information
│   └── monitoring.html # Live monitoring
├── functions/        # Netlify serverless functions
│   ├── api.js        # Main API endpoint
│   ├── get-tci.js    # Get TCI values
│   ├── get-alerts.js # Get active alerts
│   ├── get-basins.js # List basins
│   ├── get-petm.js   # PETM data
│   └── get-stats.js  # Get statistics
├── config/           # Configuration files
├── assets/           # Static assets (images, CSS, JS)
├── netlify.toml      # Netlify deployment configuration
├── package.json      # Node.js dependencies
├── .env.example      # Environment variables example
└── README.md         # This file

```

## Quick Start

### Local Development
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Install dependencies
npm install

# Start local development server
netlify dev
```

Deployment

```bash
# Deploy to Netlify
npm run deploy

# Or with specific options
netlify deploy --prod --dir=public
```

Environment Variables

Copy .env.example to .env and configure:

· SITE_NAME: Site name (STRATICA)
· SITE_URL: Production URL (https://stratica.netlify.app)
· API_BASE_URL: API endpoint (https://stratica.netlify.app/api/v1)
· TCI_FUNCTIONAL: Functional threshold (0.62)
· AUTHOR_EMAIL: Contact email (gitdeeper@gmail.com)

Serverless Functions

The functions/ directory contains Netlify Functions:

Function Endpoint Description
api.js /api Main API entry point
get-tci.js /api/tci Get TCI values for basins
get-alerts.js /api/alerts Get active alerts
get-basins.js /api/basins List all basins
get-petm.js /api/petm Get PETM case study data
get-stats.js /api/stats Get project statistics
get-parameters.js /api/parameters Get TCI parameters
get-cycles.js /api/cycles Get Milankovitch cycle data

API Usage Examples

```javascript
// Get all basins
fetch('https://stratica.netlify.app/api/basins')
  .then(res => res.json())
  .then(data => console.log(data));

// Get active alerts
fetch('https://stratica.netlify.app/api/alerts?level=alert')
  .then(res => res.json())
  .then(data => console.log(data));

// Get TCI for Shatsky Rise
fetch('https://stratica.netlify.app/api/tci?basin=shatsky-rise')
  .then(res => res.json())
  .then(data => console.log(data));

// Get PETM data
fetch('https://stratica.netlify.app/api/petm')
  .then(res => res.json())
  .then(data => console.log(data));
```

Key Results

Metric Value
TCI Accuracy 96.2%
Basins 47
Continents 6
Orbital Precision ±1,200 years
Isotope RMSD 0.0018‰
Microfossil Accuracy 93.4%
Datasets 2,800+
Study Period 4.5 billion years

Author

Samir Baladi

· Email: gitdeeper@gmail.com
· ORCID: 0009-0003-8903-0029
· Affiliation: Ronin Institute / Rite of Renaissance
· Division: Geological Deep-Time & Geospatial Intelligence

License

MIT License

Citation

```bibtex
@article{baladi2026stratica,
  title={STRATICA: Stratigraphic Pattern Recognition & Paleoclimatic Temporal Reconstruction},
  author={Baladi, Samir},
  journal={Nature Geoscience (Submitted)},
  year={2026},
  doi={10.5281/zenodo.18851076}
}
```

---

🪨 The Earth's stratigraphic column is a 4.5-billion-year journal written in rock. STRATICA decodes.

DOI: 10.5281/zenodo.18851076
