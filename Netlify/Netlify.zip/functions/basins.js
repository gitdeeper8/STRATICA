// basins.js - STRATICA Basins API
// جلب الأحواض الرسوبية من قاعدة البيانات الحقيقية
const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing Supabase credentials');
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب جميع الأحواض من قاعدة البيانات
    const { data: basins, error } = await supabase
      .from('basins')
      .select(`
        id,
        basin_code,
        basin_name,
        location,
        ocean,
        country,
        continent_code,
        latitude,
        longitude,
        depth_m,
        age_min_ma,
        age_max_ma,
        sediment_type,
        tectonic_setting,
        tci_current,
        status,
        parameters,
        last_updated,
        continents!inner (
          continent_name
        )
      `)
      .order('basin_name');

    if (error) {
      console.error('Supabase error:', error);
      throw error;
    }

    // تنسيق البيانات للـ Dashboard
    const formattedBasins = basins.map(b => ({
      id: b.id,
      basin_code: b.basin_code,
      name: b.basin_name,
      location: b.location,
      ocean: b.ocean,
      country: b.country,
      continent: b.continents?.continent_name || b.continent_code,
      latitude: b.latitude,
      longitude: b.longitude,
      depth_m: b.depth_m,
      age_range: [b.age_min_ma, b.age_max_ma],
      sediment_type: b.sediment_type,
      tectonic_setting: b.tectonic_setting,
      tci_current: b.tci_current || 0,
      status: b.status || 'UNKNOWN',
      parameters: b.parameters || {},
      last_updated: b.last_updated
    }));

    console.log(`✅ Loaded ${formattedBasins.length} basins from database`);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(formattedBasins)
    };

  } catch (error) {
    console.error('Error in basins function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: error.message,
        details: 'Failed to fetch basins from database'
      })
    };
  }
};
