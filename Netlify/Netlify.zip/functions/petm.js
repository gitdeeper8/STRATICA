// petm.js - STRATICA PETM Case Study API
// جلب بيانات PETM من قاعدة البيانات الحقيقية
const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب بيانات PETM مع معلومات الأحواض
    const { data: petm, error } = await supabase
      .from('petm_data')
      .select(`
        *,
        basins (
          basin_name,
          location,
          ocean
        )
      `)
      .order('site_name');

    if (error) throw error;

    // إذا لم توجد بيانات، استخدم البيانات الافتراضية من البحث
    if (!petm || petm.length === 0) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify([{
          event: 'Paleocene-Eocene Thermal Maximum',
          age_ma: 55.9,
          duration_kyr: 200,
          carbon_release_gtc: 3200,
          carbon_release_error: 600,
          warming_c: 5.2,
          warming_error: 0.8,
          earth_system_sensitivity: 4.8,
          ess_error: 0.6,
          sites: [
            {
              name: 'ODP Site 1209B',
              location: 'Shatsky Rise',
              ocean: 'North Pacific',
              depth_m: 2387,
              tci_pre: 0.78,
              tci_peak: 0.31,
              tci_post: 0.74,
              d13C_shift: -3.5
            }
          ]
        }])
      };
    }

    // تنسيق البيانات
    const formattedPetm = petm.map(p => ({
      site_id: p.site_id,
      site_name: p.site_name,
      basin: p.basins?.basin_name,
      location: p.basins?.location,
      ocean: p.basins?.ocean,
      depth_m: p.depth_m,
      age_ma: p.age_ma,
      tci_pre_petm: p.tci_pre_petm,
      tci_peak_petm: p.tci_peak_petm,
      tci_post_petm: p.tci_post_petm,
      d13C_shift: p.d13C_shift,
      carbon_release_gtc: p.carbon_release_gtc,
      carbon_release_error: p.carbon_release_error,
      duration_kyr: p.duration_kyr,
      warming_c: p.warming_c,
      warming_error: p.warming_error,
      earth_system_sensitivity: p.earth_system_sensitivity,
      ess_error: p.ess_error
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(formattedPetm)
    };

  } catch (error) {
    console.error('Error in petm function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
