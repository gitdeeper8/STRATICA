// parameters.js - STRATICA Parameters API
// جلب معاملات TCI من قاعدة البيانات الحقيقية
const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب تعريفات المعاملات من قاعدة البيانات
    const { data: parameters, error } = await supabase
      .from('parameter_definitions')
      .select('*')
      .order('weight', { ascending: false });

    if (error) throw error;

    // جلب آخر قيم TCI للأحواض لحساب متوسط المعاملات
    const { data: tciRecords, error: tciError } = await supabase
      .from('tci_records')
      .select('ldr_norm, iso_norm, mfa_norm, mag_norm, gch_norm, pys_norm, vsi_norm, tdm_norm, cec_norm')
      .order('sampling_date', { ascending: false })
      .limit(50);

    // حساب متوسط القيم للمعاملات
    const avgValues = {
      LDR: 0.72, ISO: 0.68, MFA: 0.65, MAG: 0.71, 
      GCH: 0.59, PYS: 0.63, VSI: 0.67, TDM: 0.70, CEC: 0.66
    };

    if (tciRecords && tciRecords.length > 0) {
      // حساب المتوسط من السجلات الفعلية
      const sum = tciRecords.reduce((acc, record) => {
        acc.LDR += record.ldr_norm || 0;
        acc.ISO += record.iso_norm || 0;
        acc.MFA += record.mfa_norm || 0;
        acc.MAG += record.mag_norm || 0;
        acc.GCH += record.gch_norm || 0;
        acc.PYS += record.pys_norm || 0;
        acc.VSI += record.vsi_norm || 0;
        acc.TDM += record.tdm_norm || 0;
        acc.CEC += record.cec_norm || 0;
        return acc;
      }, { LDR:0, ISO:0, MFA:0, MAG:0, GCH:0, PYS:0, VSI:0, TDM:0, CEC:0 });

      const count = tciRecords.length;
      avgValues.LDR = sum.LDR / count;
      avgValues.ISO = sum.ISO / count;
      avgValues.MFA = sum.MFA / count;
      avgValues.MAG = sum.MAG / count;
      avgValues.GCH = sum.GCH / count;
      avgValues.PYS = sum.PYS / count;
      avgValues.VSI = sum.VSI / count;
      avgValues.TDM = sum.TDM / count;
      avgValues.CEC = sum.CEC / count;
    }

    const colors = {
      'LDR': '#3d4a2a',
      'ISO': '#556340',
      'MFA': '#9b8b6b',
      'MAG': '#b8a985',
      'GCH': '#7a6e52',
      'PYS': '#5a5a5a',
      'VSI': '#2c2c2c',
      'TDM': '#3d4a2a',
      'CEC': '#556340'
    };

    const formattedParams = parameters.map(p => ({
      symbol: p.symbol,
      name: p.name,
      description: p.description,
      unit: p.unit,
      weight: p.weight,
      value: avgValues[p.symbol] || 0,
      color: colors[p.symbol] || '#9b8b6b',
      thresholds: {
        optimal: p.optimal_threshold,
        good: p.good_threshold,
        moderate: p.moderate_threshold,
        marginal: p.marginal_threshold,
        functional: p.functional_threshold
      }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(formattedParams)
    };

  } catch (error) {
    console.error('Error in parameters function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
