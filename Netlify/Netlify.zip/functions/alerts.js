// alerts.js - STRATICA Alerts API
// جلب التنبيهات من قاعدة البيانات الحقيقية
const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب التنبيهات النشطة مع معلومات الأحواض
    const { data: alerts, error } = await supabase
      .from('tci_alerts')
      .select(`
        id,
        basin_code,
        alert_level,
        tci_value,
        tci_reduction,
        parameter_affected,
        threshold_crossed,
        region,
        message,
        status,
        created_at,
        basins!inner (
          basin_name,
          location,
          ocean,
          latitude,
          longitude
        )
      `)
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (error) throw error;

    // تنسيق التنبيهات
    const formattedAlerts = alerts.map(a => ({
      id: a.id,
      basin: a.basins?.basin_name || a.basin_code,
      location: a.basins?.location,
      ocean: a.basins?.ocean,
      latitude: a.basins?.latitude,
      longitude: a.basins?.longitude,
      level: a.alert_level,
      tci_value: a.tci_value,
      tci_reduction: a.tci_reduction,
      parameter: a.parameter_affected,
      threshold: a.threshold_crossed,
      region: a.region,
      message: a.message,
      detected_at: a.created_at,
      severity: a.alert_level === 'MARGINAL' ? 'HIGH' : 
                a.alert_level === 'MODERATE' ? 'MEDIUM' : 'LOW'
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(formattedAlerts)
    };

  } catch (error) {
    console.error('Error in alerts function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
