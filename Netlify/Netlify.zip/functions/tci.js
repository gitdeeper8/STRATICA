// tci.js - STRATICA TCI Records API
// جلب سجلات TCI من قاعدة البيانات الحقيقية
const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const basinCode = event.queryStringParameters?.basin;
    const limit = event.queryStringParameters?.limit || 100;

    let query = supabase
      .from('tci_records')
      .select(`
        id,
        record_id,
        basin_code,
        sampling_date,
        depth_m,
        age_ma,
        ldr_raw, iso_raw, mfa_raw, mag_raw, gch_raw, pys_raw, vsi_raw, tdm_raw, cec_raw,
        ldr_norm, iso_norm, mfa_norm, mag_norm, gch_norm, pys_norm, vsi_norm, tdm_norm, cec_norm,
        tci_score,
        alert_level,
        geomagnetic_reversal,
        milankovitch_detected,
        orbital_precision_yr,
        created_at,
        basins (
          basin_name,
          location,
          ocean
        )
      `)
      .order('sampling_date', { ascending: false });

    if (basinCode) {
      query = query.eq('basin_code', basinCode);
    }

    const { data: tci, error } = await query.limit(limit);

    if (error) throw error;

    // تنسيق البيانات
    const formattedTci = tci.map(t => ({
      record_id: t.record_id,
      basin: t.basins?.basin_name || t.basin_code,
      date: t.sampling_date,
      depth_m: t.depth_m,
      age_ma: t.age_ma,
      parameters: {
        LDR: { raw: t.ldr_raw, norm: t.ldr_norm },
        ISO: { raw: t.iso_raw, norm: t.iso_norm },
        MFA: { raw: t.mfa_raw, norm: t.mfa_norm },
        MAG: { raw: t.mag_raw, norm: t.mag_norm },
        GCH: { raw: t.gch_raw, norm: t.gch_norm },
        PYS: { raw: t.pys_raw, norm: t.pys_norm },
        VSI: { raw: t.vsi_raw, norm: t.vsi_norm },
        TDM: { raw: t.tdm_raw, norm: t.tdm_norm },
        CEC: { raw: t.cec_raw, norm: t.cec_norm }
      },
      tci_score: t.tci_score,
      alert_level: t.alert_level,
      geomagnetic_reversal: t.geomagnetic_reversal,
      milankovitch_detected: t.milankovitch_detected,
      orbital_precision: t.orbital_precision_yr
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(formattedTci)
    };

  } catch (error) {
    console.error('Error in tci function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
